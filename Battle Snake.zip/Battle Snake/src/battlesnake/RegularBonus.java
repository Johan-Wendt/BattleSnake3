
package battlesnake;

import javafx.scene.paint.Color;

/**
 *
 * @author johanwendt
 */
public class RegularBonus extends Bonus {
    public RegularBonus(BuildingBlock bonusBlock, Color eventColor, int longevity, int eventHappening) {
        super(bonusBlock, eventColor, longevity, eventHappening);
    }
}


